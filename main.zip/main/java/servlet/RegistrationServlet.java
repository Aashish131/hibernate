package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Daosimpl.UserDaosImpl;
import UserDao.UserDao;
import model.User;

import UserDao.UserDao;
import Daosimpl.UserDaosImpl;

@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegistrationServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	response.setContentType("text/html");
	PrintWriter out= response.getWriter();
	UserDao o=new UserDaosImpl();
     String s1=request.getParameter("eId");
     
     String s2=request.getParameter("eName");
     String s3=request.getParameter("password");
     String s4=request.getParameter("emailId");
     String s5=request.getParameter("city");
     String s6=request.getParameter("g");
	
     User c=new User();
     c.setId(s1);
     c.setUsername(s2);
     c.setPassword(s3);
     c. setEmailid(s4);
     c.setCity(s5);
     c.setGender(s6);
     
     boolean a = false;
     try {
            a=o.registerUser(c);
            
     } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
     }
     if(a==true) {
            out.println("Registered");
     }
     else
     {
            out.println("Not Registered");
     }
     
}
	}


