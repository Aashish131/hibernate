package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Daosimpl.UserDaosImpl;
import UserDao.UserDao;
import model.User;


/**
 * Servlet implementation class ValidateAll
 */
@WebServlet("/ValidateAll")
public class ValidateAll extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ValidateAll() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 try {  response.setContentType("text/html");
         PrintWriter out=response.getWriter();
         UserDao o=new UserDaosImpl();
         
         String s1=request.getParameter("pass");
         String s2=request.getParameter("id");
         //out.println(s1+" "+s2);
         User cust=o.validateAll(s2, s1);
        
         
         if(cust==null) {System.out.print("hello");
               out.println("<div align='center' style='color:red>'customer id or password is incorrect</div>");
                 RequestDispatcher rd= request.getRequestDispatcher("login.jsp");
         rd.include(request,response);
         
         }
         else 
         {
                HttpSession session=request.getSession();
                session.setAttribute("userObj",cust);
            // RequestDispatcher rd= request.getRequestDispatcher("Welcome");
          //rd.forward(request,response);
             if(cust.getRole().equals("admin")) {
       	  RequestDispatcher rd1= request.getRequestDispatcher("Welcome.jsp");
                 rd1.forward(request,response);
            }
           else if(cust.getRole().equals("customer"))
            { RequestDispatcher rd= request.getRequestDispatcher("WelcomeCustomer.jsp");
            	rd.forward(request,response);
            }
         }
                               
                               }
                          
                               catch (Exception e) {
                                               e.printStackTrace();
                               }
        
    
	}

}
