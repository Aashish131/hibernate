package model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;


import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.Table;

@Entity
@Table(name="User_tab")
public class User {
	
		public User(){}

		public User(String id, String username, String gender, String emailid, String password, String city, String role) 
		{
		
		this.id = id;
		this.username = username;
		this.gender = gender;
		this.emailid = emailid;
		this.password = password;
		this.city = city;
		Role = role;
	}
		@Id
		private String id;
		private String username;
		private String gender;
		private String emailid;
		private String password;
		private String city;
		private String Role;
//		@ElementCollection
//		@JoinTable(name="PersonAddress",joinColumns=@JoinColumn(name="PersonId"))
//		private Set<Address> addrSet=new HashSet<>();
      
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public String getUsername() {
			return username;
		}
		public void setUsername(String username) {
			this.username = username;
		}
		public String getGender() {
			return gender;
		}
		public void setGender(String gender) {
			this.gender = gender;
		}
		public String getEmailid() {
			return emailid;
		}
		public void setEmailid(String emailid) {
			this.emailid = emailid;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public String getCity() {
			return city;
		}
		public void setCity(String city) {
			this.city = city;
		}
		public String getRole() {
			return Role;
		}
		public void setRole(String role) {
			Role = role;
		}
		@Override
		public String toString() {
			return "User [id=" + id + ", Username=" + username + ", gender=" + gender + ", emailid=" + emailid
					+ ", password=" + password + ", city=" + city + ", Role=" + Role + "]";
		}
		

	}




