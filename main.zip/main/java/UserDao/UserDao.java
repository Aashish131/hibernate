package UserDao;



import java.sql.PreparedStatement;
import java.util.List;

import model.User;

public interface  UserDao {
	 
		public boolean registerUser(User e)throws Exception;
	
		public List<User> getAllUser()throws Exception;
		public User validateAll(String userid,String password)throws Exception;
		public boolean deleteCustomer(String id)throws Exception ;
	}



