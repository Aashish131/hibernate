package Daosimpl;


import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.*;
import org.hibernate.query.Query;

import UserDao.UserDao;
import Utility.SessionProvider;
import model.User;


public class UserDaosImpl implements UserDao{
	
	 	SessionFactory sf=SessionProvider.getSessionFactory();
	 	
	 	
	 	public boolean registerUser(User e) throws Exception
	 	{
	 		try {
	 			Session session=sf.openSession();
	 			Transaction tx=session.beginTransaction();
	 			e.setRole("customer");
	 			session.save(e);
	 			tx.commit();
	 			session.close();
	 			return true;
	 		}
	 		catch(Exception c) {
	 			c.printStackTrace();
	 		}return false;
	 	}

	
	 public List<User> getAllUser()throws Exception
	 {	
		 
		 try 

		 {    Session session = sf.openSession();
         Query<User> query=session.createQuery("from model.User where role=:role");  
         query.setParameter("role", "customer");
         List<User> userList = query.list();
         	session.close();
         	return userList;
           }catch (Exception e) {
                  e.printStackTrace(); }
           return null;

		 
	 }
	 public User validateAll(String userid,String password)throws Exception{ try {
		 Session session=sf.openSession();
		 User obj=session.get(User.class,userid);
		 if(obj==null) {
			 return null; 
		 }
		 else {String s1=obj.getPassword();
		 if(s1.equals(password)) {
			 return obj;
		 }
		 }
		 session.close();
		 return obj;
		 
		 
	 }
	 catch (Exception e) {
		 
		 e.printStackTrace();
		 
	} return null;}
	
	 public boolean deleteCustomer(String id)throws Exception {
	try {
		Session session=sf.openSession();
		 Transaction tx=session.beginTransaction();
		 User obj=session.get(User.class,id);
		
		 if (obj == null) {
				return false;
			} else {
				session.delete(obj);
			}
		 tx.commit();
		 session.close();
		 
		return true;
	}
	catch(Exception e) {
		e.printStackTrace();
	}
	 
	 return false;
	 }

}
